# Topsis-YourName-RollNumber

This package implements the **Topsis** method for multi-criteria decision-making. It calculates scores and ranks for input data based on user-provided weights and impacts.

## Installation

Install the package using pip:

